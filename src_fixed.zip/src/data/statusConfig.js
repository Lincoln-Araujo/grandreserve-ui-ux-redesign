// src/data/statusConfig.js
// Simplified status config without external icon libraries.
// Icons here are plain text symbols for maximum compatibility.

export const statusConfig = {
  confirmed: {
    label: "Confirmed",
    color: "#1E8F4B",
    icon: "●",
  },
  pending: {
    label: "Pending",
    color: "#D97706",
    icon: "●",
  },
  cancelled: {
    label: "Cancelled",
    color: "#B91C1C",
    icon: "●",
  },
  tentative: {
    label: "Tentative",
    color: "#2563EB",
    icon: "●",
  },
};
