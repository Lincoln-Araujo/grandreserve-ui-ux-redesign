// src/components/Timeline.jsx
import { useMemo, useState } from "react";
import { statusConfig } from "../data/statusConfig";
import { typeColors } from "../data/typeColors";

export default function Timeline({ events = [] }) {
  const [hoverEvent, setHoverEvent] = useState(null);
  const [tooltipPos, setTooltipPos] = useState({ x: 0, y: 0 });

  // Group events by room
  const rooms = useMemo(() => {
    const map = {};
    (events || []).forEach((ev) => {
      if (!map[ev.roomId]) {
        map[ev.roomId] = {
          roomId: ev.roomId,
          roomName: ev.roomName,
          capacity: ev.capacity || "",
          area: ev.area || "",
          events: [],
        };
      }
      map[ev.roomId].events.push(ev);
    });
    return Object.values(map);
  }, [events]);

  // Find min/max time in decimal hours
  const { minHour, maxHour } = useMemo(() => {
    if (!events || events.length === 0) {
      return { minHour: 8, maxHour: 18 };
    }
    const all = events.flatMap((ev) => {
      const s = new Date(ev.start);
      const e = new Date(ev.end);
      return [
        s.getHours() + s.getMinutes() / 60,
        e.getHours() + e.getMinutes() / 60,
      ];
    });
    const min = Math.floor(Math.min(...all));
    const max = Math.ceil(Math.max(...all));
    return { minHour: min, maxHour: max };
  }, [events]);

  const hoursArray = useMemo(() => {
    const arr = [];
    for (let h = minHour; h <= maxHour; h++) {
      arr.push(h);
    }
    return arr;
  }, [minHour, maxHour]);

  const span = Math.max(maxHour - minHour, 1);

  const getLeftPercent = (dateStr) => {
    const d = new Date(dateStr);
    const dec = d.getHours() + d.getMinutes() / 60;
    return ((dec - minHour) / span) * 100;
  };

  const getWidthPercent = (startStr, endStr) => {
    const s = new Date(startStr);
    const e = new Date(endStr);
    const sd = s.getHours() + s.getMinutes() / 60;
    const ed = e.getHours() + e.getMinutes() / 60;
    return ((ed - sd) / span) * 100;
  };

  const formatHourLabel = (h) =>
    `${String(h).padStart(2, "0")}:00`;

  const formatTime = (dateStr) => {
    const d = new Date(dateStr);
    const h = String(d.getHours()).padStart(2, "0");
    const m = String(d.getMinutes()).padStart(2, "0");
    return `${h}:${m}`;
  };

  const handleEnterBlock = (ev, e) => {
    setHoverEvent(ev);
    if (e && e.clientX != null) {
      setTooltipPos({ x: e.clientX, y: e.clientY });
    }
  };

  const handleLeaveBlock = () => {
    setHoverEvent(null);
  };

  return (
    <div className="relative w-full space-y-6">
      {/* Hours header row */}
      <div className="flex pl-48 pr-4 text-xs text-gray-500">
        <div className="flex-1 relative h-5">
          {hoursArray.map((h) => {
            const offset = ((h - minHour) / span) * 100;
            return (
              <div
                key={h}
                className="absolute -translate-x-1/2"
                style={{ left: `${offset}%`, top: 0 }}
              >
                {formatHourLabel(h)}
              </div>
            );
          })}
        </div>
      </div>

      {/* Room rows */}
      {rooms.map((room) => (
        <div
          key={room.roomId}
          className="border-t border-gray-200 pt-4 pb-4"
        >
          <div className="flex w-full items-start gap-4">
            {/* Room info */}
            <div className="w-48 pr-2 text-sm text-gray-800">
              <div className="font-semibold">{room.roomName}</div>
              {(room.capacity || room.area) && (
                <div className="text-xs text-gray-500">
                  {room.capacity || "—"}
                  {room.area ? ` • ${room.area}` : ""}
                </div>
              )}
            </div>

            {/* Timeline blocks */}
            <div className="relative flex-1 h-16 bg-white rounded-md">
              {/* 30-min grid background */}
              <div className="absolute inset-0 flex">
                {hoursArray.map((h) => (
                  <div
                    key={h}
                    className="flex-1 border-l border-gray-200/60 bg-gray-50/40"
                  />
                ))}
              </div>

              {/* Event blocks */}
              {room.events.map((ev) => {
                const left = getLeftPercent(ev.start);
                const width = getWidthPercent(ev.start, ev.end);
                const statusMeta =
                  statusConfig[ev.status] || statusConfig.confirmed;
                const typeColor =
                  typeColors[ev.type] || typeColors.other || "#4B5563";

                return (
                  <button
                    key={ev.id}
                    type="button"
                    onMouseEnter={(e) => handleEnterBlock(ev, e)}
                    onMouseLeave={handleLeaveBlock}
                    className="
                      absolute h-7 rounded-md flex items-center gap-1 px-2
                      text-[11px] text-white shadow-sm cursor-pointer
                      focus:outline-none focus:ring-2 focus:ring-offset-1 focus:ring-blue-500
                    "
                    style={{
                      left: `${left}%`,
                      width: `${width}%`,
                      minWidth: "6%",
                      backgroundColor: typeColor,
                      border: `2px solid ${statusMeta.color}`,
                    }}
                    aria-label={`${ev.title}, ${formatTime(
                      ev.start
                    )} to ${formatTime(ev.end)}`}
                  >
                    <span className="text-[10px]">
                      {statusMeta.icon}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      ))}

      {/* Tooltip */}
      {hoverEvent && (
        <div
          className="
            fixed z-50 bg-blue-900 text-white text-xs rounded-md px-3 py-2
            shadow-lg max-w-xs
          "
          style={{
            top: tooltipPos.y + 12,
            left: tooltipPos.x + 12,
          }}
        >
          <div className="font-semibold mb-1">
            {hoverEvent.title}
          </div>
          <div>
            {formatTime(hoverEvent.start)} – {formatTime(hoverEvent.end)}
          </div>
          <div className="mt-1 text-[11px] opacity-90">
            {hoverEvent.roomName}
          </div>
        </div>
      )}
    </div>
  );
}
