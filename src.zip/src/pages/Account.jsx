export default function Account() {
    return (
      <div>
        <h1 className="text-xl font-semibold text-gray-900 mb-2">My account</h1>
        <p className="text-sm text-gray-600">
          This section is not in scope for this prototype, but it demonstrates navigation.
        </p>
      </div>
    );
  }
  