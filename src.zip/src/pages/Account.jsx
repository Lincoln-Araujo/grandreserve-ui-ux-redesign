export default function Account() {
    return (
      <div className="w-full min-h-[80vh] max-w-[1600px] mx-auto px-6 py-6">
        <h1 className="text-xl font-semibold text-gray-900 mb-2">My account</h1>
        <p className="text-sm text-gray-600">
          This section is not in scope for this prototype, but it demonstrates navigation.
        </p>
      </div>
    );
  }
  